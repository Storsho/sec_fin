from Crypto.Cipher import DES 
from Crypto.Util.Padding import pad,unpad
from Crypto.Random import get_random_bytes

text = input("Enter text: ")
key = input("Enter key: ").encode()

cipher = DES.new(key, DES.MODE_ECB)
cipher_text = cipher.encrypt(pad(text.encode(),DES.block_size))
print(cipher_text)
decrypted = unpad(cipher.decrypt(cipher_text),DES.block_size).decode()
print(decrypted)

#for cbc
iv = get_random_bytes(8)
cipher = DES.new(key,DES.MODE_CBC,iv)

#for aes replace everything by AES, and its 16 bytes