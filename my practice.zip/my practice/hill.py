def mod_inv(a,m=26):
    for i in range(1,m):
        if (a*i)% m == 1:
            return i
    return None

def hill_inverse(k):
    a,b = k[0]
    c,d = k[1]
    det = (a*d- b*c)
    inv = mod_inv(det)
    
    if inv is None:
        return None
    return [[d*inv % 26, -b*inv%26],
            [-c*inv%26, a*inv%26]]

def hill(k,text):
    text = text.upper().replace(" ","")
    if len(text) % 2:
        text+="X"
    result = ""
    
    for i in range(0,len(text),2):
        x,y = ord(text[i]) - 65, ord(text[i+1]) - 65
        result += chr((k[0][0]*x + k[0][1]*y) % 26 + 65)
        result += chr((k[1][0]*x + k[1][1]*y) % 26 + 65)
        
    return result

K = [[3, 3], [2, 5]]
inv = hill_inverse(K)

if inv:
    text = input("Enter plaintext: ")
    encrypted = hill (K,text)
    print("Encrypted: ",encrypted)
    decrypted = hill(inv,encrypted)
    print("Decrypted", decrypted)
    
else:
    print("Invalid key")
    