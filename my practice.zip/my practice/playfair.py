def playfair_matrix(k):
    k = k.upper().replace("J","I")
    letters = []
    for ch in k + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if ch not in letters:
            letters.append(ch)
            
    return [letters[i:i+5] for i in range(0,25,5)]
    

def prepare(text):
    text = ''.join(ch for ch in text.upper().replace("J","I") if "A" <= ch <= "Z")
    result = ''
    
    i = 0
    while i < len(text):
        result += text[i]
        if i+1 == len(text) or text[i] == text[i+1]:
            result += 'X'
            i+=1
        else:
            result += text[i+1]
            i+=2
    return result

def pos(matrix,ch):
    for r in range(5):
        for c in range(5):
            if matrix[r][c] == ch:
                return r,c
            
    

def playfair(matrix, text, decrypt=False):
    text = ''.join(ch for ch in text.upper().replace("J","I") if "A"<= ch <= "Z") if decrypt else prepare(text)
    step = -1 if decrypt else 1
    
    result = ''
    
    for i in range(0,len(text),2):
        r1,c1 = pos(matrix,text[i])
        r2,c2 = pos(matrix,text[i+1])
        
        if r1 == r2:
            result += matrix[r1][(c1+step)%5] + matrix[r2][(c2+step)%5]
            
        elif c1 == c2:
            result += matrix[(r1+step)%5][c1] + matrix[(r2+step)%5][c2]
            
        else:
            result += matrix[r1][c2] + matrix[r2][c1]
            
    return result
        
k = input("Enter key: ")
text = input("Enter text: ")
matrix = playfair_matrix(k)

print([matrix[i:i+5] for i in range(0,25,5)])

encrypted = playfair(matrix,text)
print(encrypted)
decrypted = playfair(matrix,encrypted,decrypt=True)
print(decrypted)

