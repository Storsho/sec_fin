from sympy import Matrix

def hill(k,text):
    text = text.upper().replace(" ","")
    if len(text) % 2:
        text+="X"
    result = ""
    
    for i in range(0,len(text),2):
        x,y = ord(text[i]) - 65, ord(text[i+1]) - 65
        result += chr((k[0][0]*x + k[0][1]*y) % 26 + 65)
        result += chr((k[1][0]*x + k[1][1]*y) % 26 + 65)
        
    return result

K = [[3, 3], [2, 5]]
A = Matrix(K)
inv = A.inv_mod(26)


if inv:
    text = input("Enter plaintext: ")
    encrypted = hill (K,text)
    print("Encrypted: ",encrypted)
    decrypted = hill(inv,encrypted)
    print("Decrypted", decrypted)
    
else:
    print("Invalid key")
    