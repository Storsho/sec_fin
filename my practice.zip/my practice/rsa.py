from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

key = RSA.generate(2048)
private_key = key
public_key = key.publickey()

text = input("Enter Message: ")
cipher = PKCS1_OAEP.new(public_key)
cipher_text = cipher.encrypt(text.encode())
print(cipher_text.hex())

cipher = PKCS1_OAEP.new(private_key)
decrypted = cipher.decrypt(cipher_text)
print(decrypted.decode())