
def encrypt(text, rails):
    fence = [''] * rails
    row, direction = 0, 1

    for ch in text:
        fence[row] += ch
        if row == 0:
            direction = 1
        elif row == rails - 1:
            direction = -1
        row += direction

    return ''.join(fence)


def decrypt(cipher, rails):
    pattern = []
    row, direction = 0, 1

    for ch in cipher:
        pattern.append(row)
        if row == 0:
            direction = 1
        elif row == rails - 1:
            direction = -1
        row += direction

    counts = [pattern.count(r) for r in range(rails)]
    fence = []
    start = 0

    for count in counts:
        fence.append(list(cipher[start:start + count]))
        start += count

    result = ''
    for r in pattern:
        result += fence[r].pop(0)

    return result


text = input("Enter plaintext: ").replace(" ", "").upper()
rails = int(input("Enter number of rails: "))

if rails < 2:
    print("Number of rails must be at least 2")
else:
    cipher = encrypt(text, rails)
    print("Encrypted:", cipher)
    print("Decrypted:", decrypt(cipher, rails))
