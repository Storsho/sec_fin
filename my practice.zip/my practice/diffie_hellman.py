p = input("Enter p: ")
g = input("Enter g : ")
a = input("Enter a: ")
b = input("Enter b: ")

A = pow(g,a,p)
B = pow(g,b,p)

alice_shared = pow(B,a,p)
bob_shared = pow(A,b,p)