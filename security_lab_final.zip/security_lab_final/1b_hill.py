# EXPERIMENT 1(b): HILL CIPHER
# Problem statement: Implement a 2x2 Hill cipher using modular arithmetic and an invertible key matrix.

# ---------------- HILL (2x2) ----------------
def mod_inverse(a, m=26):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None


def hill_inverse(K):
    a, b = K[0]
    c, d = K[1]

    det = (a * d - b * c) % 26
    inv_det = mod_inverse(det)

    if inv_det is None:
        return None

    return [
        [d * inv_det % 26, (-b) * inv_det % 26],
        [(-c) * inv_det % 26, a * inv_det % 26]
    ]


def hill_transform(K, text):
    text = ''.join(
        ch for ch in text.upper()
        if 'A' <= ch <= 'Z'
    )

    if len(text) % 2:
        text += 'X'

    out = ''

    for i in range(0, len(text), 2):
        x = ord(text[i]) - 65
        y = ord(text[i + 1]) - 65

        out += chr(
            (K[0][0] * x + K[0][1] * y) % 26 + 65
        )
        out += chr(
            (K[1][0] * x + K[1][1] * y) % 26 + 65
        )

    return out

# ---------------- MAIN ----------------
def main():
    print('\nHILL CIPHER (2x2)')

    try:
        a = int(input('a: '))
        b = int(input('b: '))
        c = int(input('c: '))
        d = int(input('d: '))
    except ValueError:
        print('Matrix entries must be integers.')
        return

    K = [[a, b], [c, d]]
    inv = hill_inverse(K)

    if inv is None:
        print('Invalid key: determinant has no inverse modulo 26.')
        return

    plain = input('Enter plaintext: ')
    cipher = hill_transform(K, plain)

    print('Encrypted:', cipher)
    print(
        'Decrypted (X may be padding):',
        hill_transform(inv, cipher)
    )


if __name__ == '__main__':
    main()
