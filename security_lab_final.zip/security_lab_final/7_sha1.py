# EXPERIMENT 7: SHA-1 MESSAGE DIGEST
# Problem statement: Provide a menu to generate a SHA-1 digest, demonstrate the avalanche
# effect, compare two messages, and show SHA-1 padding/length encoding in 512-bit blocks.
# SHA-1 is deprecated for security-sensitive use; this is for the lab demonstration only.
import hashlib

def sha1_hash(message):
    return hashlib.sha1(message.encode('utf-8')).hexdigest()

def generate_digest():
    message = input("Enter the message : ")
    print("Original Message : ",message)
    print("SHA-1 Digest : ",sha1_hash(message))

def avalanche_effect():
    message = input("Enter the message : ")
    pos = int(input("Enter the position : "))
    new = input("Enter replacement character : ")
    changed = message[:pos-1] + new + message[pos:]
    print("Original SHA-1 Digest : ",sha1_hash(message))
    print("Changed SHA-1 Digest : ",sha1_hash(changed))

def compare_messages():
    a = input("Enter the first message : ")
    b = input("Enter the second message : ")
    ha = sha1_hash(a)
    hb = sha1_hash(b)

    print("SHA-1 Digest of first message : ",ha)
    print("SHA-1 Digest of second message : ",hb)
    print("Result : ",ha==hb)

def preprocessing():
    message = input("Enter the message : ")
    bits = ''.join(format(byte,'08b')
                   for byte in message.encode('utf-8'))
    length = len(bits)

    padded = bits + '1'
    padded += '0' * ((448 - len(padded) % 512) % 512)
    padded += format(length,'064b')

    print("Binary : ",bits)
    print("Original Length :", length , "bits")
    print("64 bit length : ",format(length,'064b'))
    print("Total padded length : ",len(padded))

    for i in range(0,len(padded),512):
        print("Block : ",padded[i:i+512])

    print("SHA-1 Digest : ",sha1_hash(message))

while True:
    print("\n1. Generate digest")
    print("2. Avalanche effect")
    print("3. Compare messages")
    print("4. Preprocessing")
    print("5. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        generate_digest()
    elif choice == '2':
        avalanche_effect()
    elif choice == '3':
        compare_messages()
    elif choice == '4':
        preprocessing()
    elif choice == '5':
        break
    else:
        print("Invalid choice")
