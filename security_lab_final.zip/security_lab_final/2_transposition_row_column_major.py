# EXPERIMENT 2: TRANSPOSITION TECHNIQUES — ROW MAJOR AND COLUMN MAJOR
# Problem statement: Implement row-major transformation (fill column-wise, read row-wise)
# and column-major transformation (fill row-wise, read column-wise), with X padding,
# display matrices, and decrypt each ciphertext back to the plaintext.

import math

def make_matrix(text, cols, fill_by_columns):
    rows = math.ceil(len(text) / cols)
    text += 'X' * (rows * cols - len(text))
    matrix = [[''] * cols for _ in range(rows)]
    k = 0

    if fill_by_columns:
        for c in range(cols):
            for r in range(rows):
                matrix[r][c] = text[k]
                k += 1
    else:
        for r in range(rows):
            for c in range(cols):
                matrix[r][c] = text[k]
                k += 1
    return matrix

def row_major_encrypt(text, cols):
    m = make_matrix(text, cols, True)
    return ''.join(ch for row in m for ch in row)

def row_major_decrypt(cipher, cols):
    rows = len(cipher) // cols
    m = [[''] * cols for _ in range(rows)]
    k = 0
    for r in range(rows):
        for c in range(cols):
            m[r][c] = cipher[k]
            k += 1
    return ''.join(m[r][c] for c in range(cols)
                   for r in range(rows)).rstrip('X')

def column_major_encrypt(text, cols):
    m = make_matrix(text, cols, False)
    return ''.join(m[r][c] for c in range(cols)
                   for r in range(len(m)))

def column_major_decrypt(cipher, cols):
    rows = len(cipher) // cols
    m = [[''] * cols for _ in range(rows)]
    k = 0
    for c in range(cols):
        for r in range(rows):
            m[r][c] = cipher[k]
            k += 1
    return ''.join(ch for row in m for ch in row).rstrip('X')

text = ''.join(input("Enter plaintext: ").split()).upper()
cols = int(input("Enter number of columns: "))

# ADDED FROM RECORD: display the encryption matrix
def print_matrix(matrix):
    for row in matrix:
        print(' '.join(row))

# ADDED (Lab Test Set 4 Q1 - columnar = column major below): show padded plaintext
rows = math.ceil(len(text) / cols)
print("Padded Plaintext:", text + 'X' * (rows * cols - len(text)))

print("Row Major Matrix (filled column-wise):")
print_matrix(make_matrix(text, cols, True))
c1 = row_major_encrypt(text, cols)
print("Row Major Ciphertext:", c1)
print("Row Major Decrypted:", row_major_decrypt(c1, cols))

print("Column Major Matrix (filled row-wise):")
print_matrix(make_matrix(text, cols, False))
c2 = column_major_encrypt(text, cols)
print("Column Major Ciphertext:", c2)
print("Column Major Decrypted:", column_major_decrypt(c2, cols))

