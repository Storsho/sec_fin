# EXPERIMENT 6: DIFFIE–HELLMAN KEY EXCHANGE
# Problem statement: Read public values p and g and private values for Alice and Bob,
# calculate their public keys and independently calculate/compare their shared secret.
# Small values are for demonstration only, not production cryptography.
def main():
    p = int(input("Enter prime number (p): "))
    g = int(input("Enter primitive root (g): "))
    a = int(input("Enter Alice's private key: "))
    b = int(input("Enter Bob's private key: "))

    A = pow(g, a, p)
    B = pow(g, b, p)

    alice_shared = pow(B, a, p)
    bob_shared = pow(A, b, p)

    print("Alice's Public Key:", A)
    print("Bob's Public Key:", B)
    print("Shared Secret:", alice_shared)
    print("Verification:", alice_shared == bob_shared)

if __name__ == "__main__":
    main()
