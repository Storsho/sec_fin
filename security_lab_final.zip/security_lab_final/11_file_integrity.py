# EXPERIMENT 8: MD5 MESSAGE DIGEST AND FILE INTEGRITY MONITORING
# Problem statement: Menu-driven MD5 digest generation, message-integrity verification,
# avalanche-effect demonstration, file checksum generation, and MD5/SHA-1/SHA-256 comparison.
# MD5 and SHA-1 are collision-broken; use SHA-256 or stronger for security-sensitive work.

import hashlib

def md5_hash(text):
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def generate_md5():
    text = input("Enter message: ")
    print("MD5 Digest:", md5_hash(text))

def verify_integrity():
    text = input("Enter message: ")
    given = input("Enter previous MD5 digest: ")
    actual = md5_hash(text)
    print("Calculated:", actual)
    print("Integrity:", actual == given)

def avalanche_effect():
    a = input("Enter first message: ")
    b = input("Enter modified message: ")
    print("MD5 1:", md5_hash(a))
    print("MD5 2:", md5_hash(b))

def file_checksum():
    path = input("Enter file path: ")
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(4096), b''):
            h.update(block)
    print("File MD5:", h.hexdigest())

def compare_hashes():
    text = input("Enter message: ")
    data = text.encode()
    print("MD5:", hashlib.md5(data).hexdigest())
    print("SHA-1:", hashlib.sha1(data).hexdigest())
    print("SHA-256:", hashlib.sha256(data).hexdigest())

# ---------- ADDED FROM RECORD: FILE INTEGRITY MONITORING SYSTEM (option 7) ----------
import json, os
RECORD_FILE = "checksums.json"

def md5_file(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(4096), b''):
            h.update(block)
    return h.hexdigest()

def file_integrity_monitor():
    directory = input("Enter directory to monitor: ")
    old = {}
    if os.path.exists(RECORD_FILE):                 # load previous checksums
        with open(RECORD_FILE) as f:
            old = json.load(f)

    current = {}
    for root, dirs, files in os.walk(directory):     # checksum every file now
        for name in files:
            path = os.path.abspath(os.path.join(root, name))
            if path != os.path.abspath(RECORD_FILE):
                current[path] = md5_file(path)

    for path, old_sum in old.items():               # compare old vs new
        if path not in current:
            print("Missing File :", path)
        elif current[path] == old_sum:
            print("Not Modified :", path)
        else:
            print("Modified     :", path)
    for path in current:
        if path not in old:
            print("New File     :", path)

    with open(RECORD_FILE, 'w') as f:                # save for next run
        json.dump(current, f, indent=4)
    print("Checksum record updated:", RECORD_FILE)

while True:
    print("\n1. Generate MD5")
    print("2. Verify integrity")
    print("3. Avalanche effect")
    print("4. File checksum")
    print("5. Compare hashes")
    print("6. Exit")
    print("7. File Integrity Monitoring")
    choice = input("Enter choice: ")

    if choice == '1':
        generate_md5()
    elif choice == '2':
        verify_integrity()
    elif choice == '3':
        avalanche_effect()
    elif choice == '4':
        file_checksum()
    elif choice == '5':
        compare_hashes()
    elif choice == '6':
        break
    elif choice == '7':
        file_integrity_monitor()
    else:
        print("Invalid choice")

