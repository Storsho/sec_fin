# LAB TEST 1 (SET 3 Q1): HILL CIPHER WITH DETERMINANT / INVERTIBILITY CHECK
# Problem statement: Hill cipher encryption and decryption with a 2x2 key matrix.
# Test case: Key = [[3, 3], [2, 5]], Plaintext = HELP
# Convert letters to numbers (A=0..Z=25), display key matrix and determinant, verify
# gcd(det, 26) = 1, generate the inverse key matrix mod 26, encrypt and decrypt.
# Extension: accept a user key matrix and report whether it is invertible mod 26.
from math import gcd

def mod_inverse(a, m=26):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

def determinant(K):
    return (K[0][0] * K[1][1] - K[0][1] * K[1][0]) % 26

def is_invertible(K):
    return gcd(determinant(K), 26) == 1

def inverse_matrix(K):
    a, b = K[0]
    c, d = K[1]
    inv_det = mod_inverse(determinant(K))
    # inverse = det^-1 * adjugate  (adjugate of [[a,b],[c,d]] = [[d,-b],[-c,a]])
    return [[(d * inv_det) % 26, (-b * inv_det) % 26],
            [(-c * inv_det) % 26, (a * inv_det) % 26]]

def to_numbers(text):
    return [ord(ch) - 65 for ch in text]

def hill_transform(K, text):
    out = ''
    for i in range(0, len(text), 2):
        x, y = ord(text[i]) - 65, ord(text[i + 1]) - 65
        out += chr((K[0][0] * x + K[0][1] * y) % 26 + 65)
        out += chr((K[1][0] * x + K[1][1] * y) % 26 + 65)
    return out

def run(K, plaintext):
    plaintext = ''.join(ch for ch in plaintext.upper() if ch.isalpha())
    if len(plaintext) % 2:
        plaintext += 'X'

    print("Key Matrix:")
    for row in K:
        print(row)
    print("Plaintext:", plaintext)
    print("Numerical values:", to_numbers(plaintext))

    det = determinant(K)
    print("Determinant (mod 26):", det)
    print("gcd(det, 26):", gcd(det, 26))
    if not is_invertible(K):
        print("Key matrix is NOT invertible mod 26 - cannot be used")
        return

    inv = inverse_matrix(K)
    print("Inverse of det:", mod_inverse(det))
    print("Inverse Key Matrix:")
    for row in inv:
        print(row)

    cipher = hill_transform(K, plaintext)
    print("Ciphertext:", cipher)
    print("Decrypted:", hill_transform(inv, cipher))

# ---------- Given test case ----------
run([[3, 3], [2, 5]], "HELP")

# ---------- Extension: user key matrix ----------
print("\nEnter your own 2x2 key matrix")
a = int(input("a: "))
b = int(input("b: "))
c = int(input("c: "))
d = int(input("d: "))
K = [[a, b], [c, d]]

if is_invertible(K):
    print("Matrix is suitable (invertible mod 26)")
    run(K, input("Enter plaintext: "))
else:
    print("Matrix is NOT suitable: det =", determinant(K),
          ", gcd(det, 26) =", gcd(determinant(K), 26))
