# EXPERIMENT 9: DIGITAL SIGNATURE SYSTEM — RSA WITH SHA-256
# Problem statement: Menu-driven generation of RSA keys, signing and verifying messages,
# detecting message tampering, and simulating signed e-mail communication.

from pathlib import Path
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

PRIV = Path("private_key.pem")
PUB = Path("public_key.pem")
SIG = Path("signature.txt")
MSG = Path("signed_message.txt")

def generate_keys():
    key = RSA.generate(2048)
    PRIV.write_bytes(key.export_key())
    PUB.write_bytes(key.publickey().export_key())
    print("RSA keys generated and saved")

def sign_message():
    if not PRIV.exists():
        print("Generate keys first")
        return

    key = RSA.import_key(PRIV.read_bytes())
    message = input("Enter message: ")
    digest = SHA256.new(message.encode())
    signature = pkcs1_15.new(key).sign(digest)

    SIG.write_text(signature.hex())
    MSG.write_text(message)
    print("SHA-256:", digest.hexdigest())
    print("Signature:", signature.hex())

def verify_signature():
    if not PUB.exists():
        print("Generate keys first")
        return

    key = RSA.import_key(PUB.read_bytes())
    message = input("Enter received message: ")
    sig = bytes.fromhex(input("Enter signature (hex): "))

    try:
        digest = SHA256.new(message.encode())
        pkcs1_15.new(key).verify(digest, sig)
        print("Signature: VALID")
    except (ValueError, TypeError):
        print("Signature: INVALID")

def demonstrate_tampering():
    if not PRIV.exists() or not PUB.exists():
        print("Generate keys first")
        return

    private = RSA.import_key(PRIV.read_bytes())
    public = RSA.import_key(PUB.read_bytes())
    original = input("Enter original message: ")

    sig = pkcs1_15.new(private).sign(
        SHA256.new(original.encode()))

    modified = input("Enter modified message: ")
    try:
        pkcs1_15.new(public).verify(
            SHA256.new(modified.encode()), sig)
        print("Tampered message: VALID")
    except (ValueError, TypeError):
        print("Tampering detected: INVALID")

def secure_email():
    alice = RSA.generate(2048)
    public = alice.publickey()
    message = input("Alice - enter message: ")

    sig = pkcs1_15.new(alice).sign(
        SHA256.new(message.encode()))
    print("Message sent to Bob:", message)

    for received in [message, input("Enter modified message: ")]:
        try:
            pkcs1_15.new(public).verify(
                SHA256.new(received.encode()), sig)
            print("Bob verifies: VALID")
        except (ValueError, TypeError):
            print("Bob verifies: INVALID")

while True:
    print("\n1. Generate keys\n2. Sign message")
    print("3. Verify signature\n4. Detect tampering")
    print("5. Secure email simulation\n6. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        generate_keys()
    elif choice == '2':
        sign_message()
    elif choice == '3':
        verify_signature()
    elif choice == '4':
        demonstrate_tampering()
    elif choice == '5':
        secure_email()
    elif choice == '6':
        break
    else:
        print("Invalid choice")

