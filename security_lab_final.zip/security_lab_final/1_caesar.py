# EXPERIMENT 1(a): CAESAR CIPHER — MENU-DRIVEN IMPLEMENTATION
# Problem statement: Implement Caesar cipher encryption, decryption, brute-force attack,
# and exit options. Preserve letter case and leave non-alphabetic characters unchanged.
def shift_text(text,key):
    result=""
    for ch in text:
        if 'a' <= ch <= 'z':
            result += chr((ord(ch) - ord('a') + key) % 26 + ord('a'))
        elif 'A' <= ch <= 'Z':
            result += chr((ord(ch) - ord('A') + key) % 26 + ord('A'))
        else:
            result+=ch
    return result

while True:
    print("\n1. Encrypt\n2. Decrypt\n3. Brute Force\n4. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        text = input("Enter plaintext: ")
        key = int(input("Enter key: "))
        print("Encrypted:", shift_text(text, key))

    elif choice == '2':
        text = input("Enter ciphertext: ")
        key = int(input("Enter key: "))
        print("Decrypted:", shift_text(text, -key))

    elif choice == '3':
        text = input("Enter ciphertext: ")
        for key in range(26):
            print("Key", key, ":", shift_text(text, -key))

    elif choice == '4':
        break

    else:
        print("Invalid choice")