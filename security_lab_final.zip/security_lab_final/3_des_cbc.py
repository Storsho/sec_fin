# EXPERIMENT 3: DATA ENCRYPTION STANDARD (DES)
# Problem statement: Encrypt a plaintext using DES and an 8-byte key in CBC mode,
# display ciphertext as hexadecimal, decrypt it, remove padding, and verify recovery.
# Educational lab example only: DES and CBC are not secure for real-world use.
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

plaintext = input("Enter plaintext : ")
key = input("Enter 8-character key : ").encode()

iv = get_random_bytes(8)
cipher = DES.new(key,DES.MODE_CBC,iv)
ciphertext = cipher.encrypt(pad(plaintext.encode(),DES.block_size))
print("Ciphertext (hex) : ", ciphertext.hex())

cipher = DES.new(key,DES.MODE_CBC,iv)
decrypted = unpad(cipher.decrypt(ciphertext),DES.block_size).decode()
print("Decrypted : ", decrypted)
print("Verification : ",decrypted==plaintext)