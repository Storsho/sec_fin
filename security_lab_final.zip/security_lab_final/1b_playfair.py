# EXPERIMENT 1(b): PLAYFAIR CIPHER
# Problem statement: Implement Playfair cipher using a 5x5 keyword matrix with I/J combined.

# ---------------- PLAYFAIR ----------------
def playfair_matrix(keyword):
    keyword = keyword.upper().replace('J', 'I')
    letters = []

    for ch in keyword + 'ABCDEFGHIKLMNOPQRSTUVWXYZ':
        if 'A' <= ch <= 'Z' and ch not in letters:
            letters.append(ch)

    return [letters[i:i+5] for i in range(0, 25, 5)]


def pf_pos(matrix, ch):
    for r, row in enumerate(matrix):
        if ch in row:
            return r, row.index(ch)


def playfair_prepare(text):
    text = ''.join(
        ch for ch in text.upper().replace('J', 'I')
        if 'A' <= ch <= 'Z'
    )

    out = []
    i = 0

    while i < len(text):
        a = text[i]

        if i + 1 >= len(text):
            out.extend([a, 'X'])
            i += 1
        elif text[i + 1] == a:
            out.extend([a, 'X'])
            i += 1
        else:
            out.extend([a, text[i + 1]])
            i += 2

    return ''.join(out)


def playfair_transform(matrix, text, decrypt=False):
    if decrypt:
        text = ''.join(
            ch for ch in text.upper().replace('J', 'I')
            if 'A' <= ch <= 'Z'
        )
    else:
        text = playfair_prepare(text)

    step = -1 if decrypt else 1
    out = []

    for i in range(0, len(text), 2):
        r1, c1 = pf_pos(matrix, text[i])
        r2, c2 = pf_pos(matrix, text[i + 1])

        if r1 == r2:
            out.extend([
                matrix[r1][(c1 + step) % 5],
                matrix[r2][(c2 + step) % 5]
            ])
        elif c1 == c2:
            out.extend([
                matrix[(r1 + step) % 5][c1],
                matrix[(r2 + step) % 5][c2]
            ])
        else:
            out.extend([
                matrix[r1][c2],
                matrix[r2][c1]
            ])

    return ''.join(out)


# ---------------- MAIN ----------------
def main():
    print('PLAYFAIR CIPHER')

    key = input('Enter keyword: ').strip() or 'Monarchy'
    matrix = playfair_matrix(key)

    print('Key matrix:')
    for row in matrix:
        print(' '.join(row))

    plain = input('Enter plaintext: ')
    cipher = playfair_transform(matrix, plain)

    print('Prepared plaintext:', playfair_prepare(plain))
    print('Encrypted:', cipher)
    print(
        'Decrypted (X may be filler):',
        playfair_transform(matrix, cipher, True)
    )


if __name__ == '__main__':
    main()
