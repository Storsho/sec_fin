# LAB TEST 2 (SET 3 Q2): RSA WITH SMALL PRIMES (MANUAL, NO LIBRARY)
# Problem statement: RSA encryption/decryption with p = 61, q = 53, e = 17, M = 88.
# Calculate n = p*q and phi(n) = (p-1)(q-1), verify gcd(e, phi) = 1, find d such that
# (e*d) mod phi = 1, display public key (e, n) and private key (d, n), encrypt, decrypt.
# Extension: function to check (p, q, e) validity: p, q prime; gcd(e, phi) = 1; 1 < e < phi.
from math import gcd

def is_prime(n):                            # only needed for the extension
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def is_valid_rsa(p, q, e):
    phi = (p - 1) * (q - 1)
    return is_prime(p) and is_prime(q) and p != q and 1 < e < phi and gcd(e, phi) == 1

def rsa(p, q, e, M):
    n = p * q
    phi = (p - 1) * (q - 1)
    print("n = p * q =", n)
    print("phi(n) = (p-1)(q-1) =", phi)
    print("gcd(e, phi) =", gcd(e, phi))

    d = pow(e, -1, phi)                     # modular inverse: (e*d) % phi == 1
    print("d =", d, " check (e*d) mod phi =", (e * d) % phi)
    print("Public Key (e, n) =", (e, n))
    print("Private Key (d, n) =", (d, n))

    C = pow(M, e, n)                        # encrypt: C = M^e mod n
    print("Ciphertext C =", C)
    R = pow(C, d, n)                        # decrypt: M = C^d mod n
    print("Decrypted M =", R)
    print("Verification:", R == M)

# ---------- Given test case ----------
rsa(61, 53, 17, 88)

# ---------- Extension ----------
print("\nCheck your own (p, q, e)")
p = int(input("p: "))
q = int(input("q: "))
e = int(input("e: "))
if is_valid_rsa(p, q, e):
    print("Valid RSA parameters")
    M = int(input("Enter message M (must be < n): "))
    rsa(p, q, e, M)
else:
    print("Invalid RSA parameters")
