# LAB TEST 3 (SET 4 Q2): AES ENCRYPTION IN CBC MODE (APPLICATION-BASED)
# Problem statement: AES-CBC encryption/decryption using PyCryptodome.
# Plaintext = CYBER SECURITY LABORATORY
# Key (hex) = 0F0E0D0C0B0A09080706050403020100, IV (hex) = 00000000000000000000000000000000
# Encrypt, display ciphertext, decrypt, display recovered plaintext, verify.
# Extension: change ONE character (CYBER -> CYBEV) and compare the two ciphertexts.
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

key = bytes.fromhex("0F0E0D0C0B0A09080706050403020100")
iv = bytes.fromhex("00000000000000000000000000000000")
plaintext = "CYBER SECURITY LABORATORY"

def encrypt(text):
    cipher = AES.new(key, AES.MODE_CBC, iv)       # new object for every operation
    return cipher.encrypt(pad(text.encode(), AES.block_size))

def decrypt(ct):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(ct), AES.block_size).decode()

ct1 = encrypt(plaintext)
print("Plaintext  :", plaintext)
print("Ciphertext :", ct1.hex())
recovered = decrypt(ct1)
print("Decrypted  :", recovered)
print("Verification:", recovered == plaintext)

# ---------- Extension: change one character ----------
modified = plaintext.replace("CYBER", "CYBEV", 1)
ct2 = encrypt(modified)
print("\nModified   :", modified)
print("Ciphertext :", ct2.hex())

for i in range(0, len(ct1), 16):                  # compare block by block
    same = ct1[i:i+16] == ct2[i:i+16]
    print("Block", i // 16 + 1, ":", "same" if same else "CHANGED")

diff_bytes = sum(1 for a, b in zip(ct1, ct2) if a != b)
print("Bytes changed:", diff_bytes, "of", len(ct1))
# Comment: the change is in block 1, so block 1 changes completely (avalanche effect),
# and because CBC chains each block into the next, every later block changes too.
