# EXPERIMENT 4: ADVANCED ENCRYPTION STANDARD (AES-128)
# Problem statement: Encrypt a plaintext using AES with a 16-byte key in ECB mode,
# display hexadecimal ciphertext, decrypt and unpad it, and verify the recovered text.
# Educational lab example only: ECB reveals patterns and is not recommended for real data.
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

plaintext = input("Enter the plaintext : ")
key = input("Enter the 16-character key : ").encode()

cipher = AES.new(key,AES.MODE_ECB)
ciphertext = cipher.encrypt(pad(plaintext.encode(),AES.block_size))
print("Ciphertext : ", ciphertext.hex())

cipher = AES.new(key, AES.MODE_ECB)
decrypted = unpad(cipher.decrypt(ciphertext),AES.block_size).decode()
print("Decrypted : ", decrypted)
print("Verification : ", decrypted==plaintext)