# EXPERIMENT 10: SIMPLE BLOCKCHAIN WITH PROOF OF WORK
# Problem statement: Create a simple blockchain using SHA-256 hashing. Each block stores
# index, data, previous hash, nonce and its own hash. Mine blocks with Proof of Work,
# display the chain, verify it, and show that modifying a block makes the chain invalid.
import hashlib
import time

DIFFICULTY = 4                      # hash must start with "0000"

def calculate_hash(index, timestamp, data, prev_hash, nonce):
    block_string = str(index) + str(timestamp) + data + prev_hash + str(nonce)
    return hashlib.sha256(block_string.encode()).hexdigest()

def create_block(index, data, prev_hash):
    timestamp = time.time()
    nonce = 0
    # PROOF OF WORK: keep changing nonce until hash has DIFFICULTY leading zeros
    while True:
        h = calculate_hash(index, timestamp, data, prev_hash, nonce)
        if h.startswith('0' * DIFFICULTY):
            break
        nonce += 1
    return {'index': index, 'timestamp': timestamp, 'data': data,
            'prev_hash': prev_hash, 'nonce': nonce, 'hash': h}

def is_chain_valid(chain):
    for i in range(len(chain)):
        cur = chain[i]
        # 1. stored hash must equal recomputed hash (detects data change)
        if cur['hash'] != calculate_hash(cur['index'], cur['timestamp'], cur['data'],
                                         cur['prev_hash'], cur['nonce']):
            return False
        # 2. link: prev_hash must equal previous block's hash
        if i > 0 and cur['prev_hash'] != chain[i - 1]['hash']:
            return False
    return True

blockchain = [create_block(0, "Genesis Block", "0")]     # genesis block

while True:
    print("\n1. Add Block\n2. Display Blockchain\n3. Verify Blockchain")
    print("4. Modify a Block\n5. Exit")
    choice = input("Enter choice: ")

    if choice == '1':
        data = input("Enter block data: ")
        prev = blockchain[-1]
        start = time.time()
        block = create_block(len(blockchain), data, prev['hash'])
        blockchain.append(block)
        print("Block mined! Nonce:", block['nonce'],
              "Time:", round(time.time() - start, 3), "s")
        print("Hash:", block['hash'])

    elif choice == '2':
        for b in blockchain:
            print("\nIndex     :", b['index'])
            print("Data      :", b['data'])
            print("Prev Hash :", b['prev_hash'])
            print("Nonce     :", b['nonce'])
            print("Hash      :", b['hash'])

    elif choice == '3':
        print("Blockchain VALID" if is_chain_valid(blockchain) else "Blockchain INVALID")

    elif choice == '4':
        i = int(input("Enter block index to modify: "))
        blockchain[i]['data'] = input("Enter new data: ")   # hash NOT recomputed -> tamper
        print("Block", i, "modified")

    elif choice == '5':
        break

    else:
        print("Invalid choice")
