# EXPERIMENT 5: RSA ENCRYPTION AND DECRYPTION
# Problem statement: Generate a 2048-bit RSA key pair, encrypt a message with the public
# key using OAEP, decrypt with the private key, and verify that plaintext is recovered.
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

key = RSA.generate(2048)
public_key = key.publickey()
private_key = key

# ADDED FROM RECORD: display keys in PEM format
print("Public Key :\n", public_key.export_key().decode())
print("Private Key :\n", private_key.export_key().decode())

plaintext = input("Enter the plaintext : ")

cipher = PKCS1_OAEP.new(public_key)
ciphertext = cipher.encrypt(plaintext.encode())
print("Ciphertext (hex) : ", ciphertext.hex())

cipher = PKCS1_OAEP.new(private_key)
decrypted = cipher.decrypt(ciphertext).decode()
print("Decrypted : ",decrypted)
print("Verification : ",decrypted==plaintext)