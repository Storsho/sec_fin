from Crypto.PublicKey import RSA 
from Crypto.Cipher import PKCS1_OAEP

text = input("Enter text")
key = RSA.generate(2048)
public_key = key.publickey()
private_key = key

cipher = PKCS1_OAEP.new(public_key)
encrypted = cipher.encrypt(text.encode())
print(encrypted.hex())

cipher = PKCS1_OAEP.new(private_key)
decrypted = cipher.decrypt(encrypted)
print(decrypted.decode())

