from Crypto.Cipher import DES
from Crypto.Util.Padding import pad,unpad
from Crypto.Random import get_random_bytes

text = input("Enter text")
key = input("Enter key").encode()
cipher = DES.new(key, DES.MODE_ECB)

encrypted = cipher.encrypt(pad(text.encode(),8))
print(encrypted.hex())

decrypted = unpad(cipher.decrypt(encrypted), 8)
print(decrypted.decode())