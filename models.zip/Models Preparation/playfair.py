
def make_matrix(key):
    letters = ''
    for ch in (key.upper().replace('J', 'I') +
               'ABCDEFGHIKLMNOPQRSTUVWXYZ'):
        if ch.isalpha() and ch.isascii() and ch != 'J' and ch not in letters:
            letters += ch

    return [list(letters[i:i+5]) for i in range(0, 25, 5)]

def prepare(text):
    text = ''.join(ch for ch in text.upper().replace('J', 'I')
                   if ch.isalpha() and ch.isascii())

    result = ''
    i = 0

    while i < len(text):
        a = text[i]

        if i + 1 == len(text):
            result += a + 'X'
            i += 1
        elif text[i] == text[i+1]:
            result += a + 'X'
            i += 1
        else:
            result += a + text[i+1]
            i += 2

    return result

def position(matrix, ch):
    if ch == 'J':
        ch = 'I'

    for r in range(5):
        for c in range(5):
            if matrix[r][c] == ch:
                return r, c

def transform(matrix, text, decrypt=False):
    if decrypt:
        text = ''.join(ch for ch in text.upper().replace('J', 'I')
                       if ch.isalpha() and ch.isascii())
    else:
        text = prepare(text)

    result = ''
    step = -1 if decrypt else 1

    for i in range(0, len(text), 2):
        a, b = text[i], text[i+1]
        r1, c1 = position(matrix, a)
        r2, c2 = position(matrix, b)

        if r1 == r2:
            result += matrix[r1][(c1+step) % 5]
            result += matrix[r2][(c2+step) % 5]

        elif c1 == c2:
            result += matrix[(r1+step) % 5][c1]
            result += matrix[(r2+step) % 5][c2]

        else:
            result += matrix[r1][c2]
            result += matrix[r2][c1]

    return result

def main():
    key = input("Enter keyword: ")
    matrix = make_matrix(key)

    print("Key matrix:")
    for row in matrix:
        print(' '.join(row))

    text = input("Enter plaintext: ")
    encrypted = transform(matrix, text)

    print("Prepared text:", prepare(text))
    print("Encrypted:", encrypted)
    print("Decrypted:", transform(matrix, encrypted, True))

main()
