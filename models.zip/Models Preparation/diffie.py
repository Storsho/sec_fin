p = int(input("Enter prime no:"))
g = int(input("Enter primitve root:"))

a = int(input("Enter alice's private key"))
b = int(input("Enter bob's private key"))

if p<=2 or not(1<g<p) or a<=0 or b<=0:
    print("invalid input") 


A = pow(g,a,p)
B = pow(g,b,p)

Alice_key = pow(B,a,p)
Bob_key = pow(A,b,p)

if Alice_key == Bob_key:
    print("match")
else:
    print("not a match")