
from math import ceil

def make_matrix(text, cols, fill_columns):
    rows = ceil(len(text) / cols)
    text += 'X' * (rows * cols - len(text))
    matrix = [[''] * cols for _ in range(rows)]

    k = 0
    if fill_columns:
        for c in range(cols):
            for r in range(rows):
                matrix[r][c] = text[k]
                k += 1
    else:
        for r in range(rows):
            for c in range(cols):
                matrix[r][c] = text[k]
                k += 1

    return matrix

def show_matrix(matrix):
    for row in matrix:
        print(' '.join(row))

def row_encrypt(text, cols):
    matrix = make_matrix(text, cols, True)
    print("Row-major matrix:")
    show_matrix(matrix)
    return ''.join(ch for row in matrix for ch in row)

def row_decrypt(cipher, cols):
    rows = len(cipher) // cols
    matrix = [list(cipher[i:i+cols]) for i in range(0, len(cipher), cols)]

    text = ''
    for c in range(cols):
        for r in range(rows):
            text += matrix[r][c]

    return text.rstrip('X')

def column_encrypt(text, cols):
    matrix = make_matrix(text, cols, False)
    print("Column-major matrix:")
    show_matrix(matrix)

    return ''.join(matrix[r][c]
                   for c in range(cols)
                   for r in range(len(matrix)))

def column_decrypt(cipher, cols):
    rows = len(cipher) // cols
    matrix = [[''] * cols for _ in range(rows)]

    k = 0
    for c in range(cols):
        for r in range(rows):
            matrix[r][c] = cipher[k]
            k += 1

    return ''.join(ch for row in matrix for ch in row).rstrip('X')

def main():
    text = ''.join(input("Enter plaintext: ").upper().split())
    if not text:
        print("Empty plaintext")
        return

    cols = int(input("Enter number of columns: "))
    if cols <= 0:
        print("Columns must be positive")
        return

    c1 = row_encrypt(text, cols)
    print("Row-major encrypted:", c1)
    print("Row-major decrypted:", row_decrypt(c1, cols))

    c2 = column_encrypt(text, cols)
    print("Column-major encrypted:", c2)
    print("Column-major decrypted:", column_decrypt(c2, cols))

main()
