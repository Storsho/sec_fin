# EXPERIMENT 4: ADVANCED ENCRYPTION STANDARD (AES-128)
# Problem statement: Encrypt a plaintext using AES with a 16-byte key in ECB mode,
# display hexadecimal ciphertext, decrypt and unpad it, and verify the recovered text.
# Educational lab example only: ECB reveals patterns and is not recommended for real data.
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

plaintext=input('Enter the plaintext: ')
key_text=input('Enter 16-byte secret key (16 ASCII characters): ')
key=key_text.encode('utf-8')
if len(key)!=16:
    raise SystemExit('Error: key must encode to exactly 16 bytes.')
ciphertext=AES.new(key,AES.MODE_ECB).encrypt(pad(plaintext.encode('utf-8'),AES.block_size))
decrypted=unpad(AES.new(key,AES.MODE_ECB).decrypt(ciphertext),AES.block_size).decode('utf-8')
print('\n----- AES Encryption & Decryption -----')
print('Plaintext           :',plaintext)
print('Secret Key          :',key_text)
print('Ciphertext (Hex)    :',ciphertext.hex())
print('Decrypted Plaintext :',decrypted)
print('Verification        :','SUCCESS' if decrypted==plaintext else 'FAILED')
