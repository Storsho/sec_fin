from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

text = input("Enter text")
key = input("Enter key").encode()
cipher = AES.new(key, AES.MODE_ECB)

encrypted = cipher.encrypt(pad(text.encode(), 16))
print(encrypted.hex())

decrypted = unpad(cipher.decrypt(encrypted), 16)
print(decrypted.decode())

#for cbc mode 
iv = get_random_bytes(16)
cipher = AES.new(key, AES.MODE_CBC, iv)

