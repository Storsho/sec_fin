from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

def generate_keys():
    key = RSA.generate(2048)
    return key, key.publickey()

def sign_message(private_key, text):
    digest = SHA256.new(text.encode())
    return pkcs1_15.new(private_key).sign(digest)

def verify_signature(public_key, text, signature):
    try:
        digest = SHA256.new(text.encode())
        pkcs1_15.new(public_key).verify(digest, signature)
        print("Signature verified")
    except (ValueError, TypeError):
        print("Signature InValid")
        
private_key,public_key = generate_keys()

#sign the message
text = input("Enter text")
signature = sign_message(private_key, text)
print(signature.hex())

#verify signature
text = input("enter text")
signature = bytes.fromhex(input("Enter signature: "))
verify_signature(public_key, text, signature)

#tampering test
text1 = input("enter text")
signature = sign_message(private_key, text1)

text2 = input("Enter modified text")
verify_signature(public_key, text2, signature)



