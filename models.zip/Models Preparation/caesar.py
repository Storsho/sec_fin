def encrypt(text,key):
    result = ""
    for ch in text:
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            result += ch((ord(ch) - base + key)%26 + base)
        else:
            result += ch
            
    return result

# use positive key for encryption
#use negative of the same key for decryption
