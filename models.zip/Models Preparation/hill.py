
from math import gcd

def inverse(a):
    for i in range(26):
        if (a * i) % 26 == 1:
            return i
    return None

def hill_inverse(K):
    a, b = K[0]
    c, d = K[1]

    det = (a*d - b*c) % 26
    inv = inverse(det)

    if inv is None:
        return None

    return [[d*inv % 26, -b*inv % 26],
            [-c*inv % 26, a*inv % 26]]

def transform(K, text):
    text = ''.join(ch for ch in text.upper() if ch.isalpha() and ch.isascii())

    if len(text) % 2:
        text += 'X'

    result = ''

    for i in range(0, len(text), 2):
        x = ord(text[i]) - 65
        y = ord(text[i+1]) - 65

        a = (K[0][0]*x + K[0][1]*y) % 26
        b = (K[1][0]*x + K[1][1]*y) % 26

        result += chr(a + 65) + chr(b + 65)

    return result

def main():
    K = [
        [int(input("Enter a: ")), int(input("Enter b: "))],
        [int(input("Enter c: ")), int(input("Enter d: "))]
    ]

    inv = hill_inverse(K)

    if inv is None:
        print("Invalid key matrix")
        return

    text = input("Enter plaintext: ")

    encrypted = transform(K, text)
    decrypted = transform(inv, encrypted)

    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

main()
