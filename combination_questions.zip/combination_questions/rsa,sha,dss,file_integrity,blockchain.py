from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import hashlib
import json

# ---------- 1. RSA KEY GENERATION ----------
sender = RSA.generate(2048)
receiver = RSA.generate(2048)

# ---------- 2. MESSAGE HASHING AND SIGNATURE ----------
msg = input("Enter message: ").encode()
h = SHA256.new(msg)
sig = pkcs1_15.new(sender).sign(h)

print("SHA-256:", h.hexdigest())
print("Signature:", sig.hex())

# ---------- 3. RSA ENCRYPTION ----------
cipher = PKCS1_OAEP.new(receiver.publickey())
encrypted = cipher.encrypt(msg)
print("Encrypted:", encrypted.hex())

# ---------- 4. DECRYPTION AND SIGNATURE VERIFICATION ----------
decrypted = PKCS1_OAEP.new(receiver).decrypt(encrypted)
print("Decrypted:", decrypted.decode())

try:
    pkcs1_15.new(sender.publickey()).verify(
        SHA256.new(decrypted), sig
    )
    print("Signature VALID")
except (ValueError, TypeError):
    print("Signature INVALID")

# ---------- 5. FILE INTEGRITY ----------
path = input("Enter file path: ")

with open(path, "rb") as f:
    data = f.read()

file_hash = hashlib.sha256(data).hexdigest()
print("File SHA-256:", file_hash)

# Sign the file hash
file_signature = pkcs1_15.new(sender).sign(
    SHA256.new(file_hash.encode())
)

# Verify the file hash signature
try:
    pkcs1_15.new(sender.publickey()).verify(
        SHA256.new(file_hash.encode()), file_signature
    )
    print("File hash signature VALID")
except (ValueError, TypeError):
    print("File hash signature INVALID")

# ---------- 6. BLOCKCHAIN ----------
def block_hash(data, previous_hash):
    content = json.dumps(data, sort_keys=True) + previous_hash
    return hashlib.sha256(content.encode()).hexdigest()

blocks = []
previous_hash = "0"

for i in range(3):
    data = input("Enter block data: ")
    current_hash = block_hash(data, previous_hash)

    block = {
        "data": data,
        "previous_hash": previous_hash,
        "hash": current_hash
    }

    blocks.append(block)
    previous_hash = current_hash

# ---------- 7. BLOCKCHAIN VERIFICATION ----------
valid = True

for i, block in enumerate(blocks):
    if block_hash(block["data"], block["previous_hash"]) != block["hash"]:
        valid = False

    if i > 0 and block["previous_hash"] != blocks[i-1]["hash"]:
        valid = False

print("Blockchain VALID" if valid else "Blockchain TAMPERED")