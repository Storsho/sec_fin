from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from math import gcd

# Generate RSA keys from p and q
p = int(input("Enter p: "))
q = int(input("Enter q: "))

n = p * q
phi = (p - 1) * (q - 1)
e = 65537

if gcd(e, phi) != 1:
    print("Invalid p and q for this e")
else:
    d = pow(e, -1, phi)

    private_key = RSA.construct((n, e, d, p, q))
    public_key = private_key.publickey()

    print("Public key (e, n):", e, n)
    print("Private key (d, n):", d, n)

    # Input message and hash
    msg = input("Enter message: ").encode()
    h = SHA256.new(msg)
    print("SHA-256:", h.hexdigest())

    # Sign using private key
    sig = pkcs1_15.new(private_key).sign(h)

    # Encrypt using public key
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(msg)
    print("Encrypted:", encrypted.hex())

    # Decrypt using private key
    decrypted = PKCS1_OAEP.new(private_key).decrypt(encrypted)
    print("Decrypted:", decrypted.decode())

    # Verify digital signature
    try:
        pkcs1_15.new(public_key).verify(
            SHA256.new(decrypted), sig
        )
        print("Signature VALID")
    except (ValueError, TypeError):
        print("Signature INVALID")